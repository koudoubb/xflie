# Xflie Combo · 中文动态视频卡片组合技能

**中文** · 一个完整的代理技能组合：从帖子核查与中文口播稿，到 HTML/CSS 动态卡片、配音字幕、成片检查和可选的授权发布。包含主技能和三个可单独安装的阶段技能。

**English** · A coordinated agent-skill bundle for turning source posts into Simplified Chinese vertical motion cards—from research and narration copy through HTML/CSS visuals, voice, subtitles, export QA, and optional authorized publishing. Includes one orchestration skill and three standalone stage skills.

## 安装 · Install

解压 `xflie-combo.zip`，把 `skills/` 目录里的四个技能文件夹复制到 Codex 技能目录（通常为 `~/.codex/skills/`），或复制到其他兼容代理的 skills 目录。确认每个技能目录中直接包含 `SKILL.md`，然后重新载入技能。

Extract `xflie-combo.zip`. Copy all four folders from `skills/` into your Codex skills directory (usually `~/.codex/skills/`) or another compatible agent's skills directory. Each skill folder must directly contain `SKILL.md`; reload the skills afterward.

## 开始使用 · Quick start

```text
使用 $xflie 把这个 X 帖子的核心内容做成中文动态视频卡片。
先给我确认中英混合标题和完整口播稿，确认后再制作。
帖子链接：<粘贴链接>
```

```text
Use $xflie to turn the core content of this X post into a Simplified Chinese
vertical motion card. Show me the bilingual title and full narration for approval
before producing media.
Post URL: <paste URL>
```

主技能会依次指导核查、文案、视觉、后期和验证；需要时也可以单独调用各阶段技能。发布仅在用户明确授权后执行。

The main skill guides research, copy, visuals, postproduction, and validation. Stage skills can also be invoked individually. Publishing requires explicit user authorization.

## 包含技能 · Included skills

| 技能 / Skill | 功能 / Role |
| --- | --- |
| `xflie` | 端到端编排、内容边界、画面规格、发布授权与交付 / End-to-end orchestration, content boundaries, visual specs, authorized publishing, delivery |
| `xflie-script-cn` | 来源核实、自然简体中文标题与口播稿 / Source verification and natural Simplified Chinese titles and narration |
| `xflie-motion-card` | 真实案例驱动的竖版视觉、HTML/CSS 动效与封面 / Example-led vertical design, HTML/CSS motion, and covers |
| `xflie-postproduction` | 中文配音、语义字幕、同步剪辑、成片质检 / Chinese narration, semantic captions, synchronized editing, and export QA |

## 默认交付 · Default output

- 9:16 竖版视频和同尺寸封面；重要内容位于带留边的居中3:4安全区。 / 9:16 video and matching cover; key content stays within a padded centered 3:4 safe area.
- 真实案例媒体、克制动效、自然中文口播。 / Real example media, restrained motion, and natural Chinese narration.
- 白字黑边、最多两行、按语义分段的字幕。 / Semantic captions with white text, dark outline, and at most two lines.
- MP4、PNG封面、SRT字幕和可编辑工程。 / MP4, PNG cover, SRT subtitles, and editable project.

## 依赖与授权 · Requirements and permissions

该组合是供代理使用的工作流技能，不是独立视频软件。视频渲染、语音合成、浏览器和媒体探测工具需在本机另行安装及配置；可选 HyperFrames、ego-browser、FFmpeg/ffprobe 等工具，但本包不包含它们或任何密钥。发布后台是可选项，必须由用户明确授权。

This is an agent workflow bundle, not a standalone video application. Rendering, speech synthesis, browser, and media-probing tools must be installed and configured separately. HyperFrames, ego-browser, and FFmpeg/ffprobe may be used where available, but are not bundled; no API keys are included. Admin publishing is optional and requires explicit user authorization.

复用源媒体前核对版权、许可与平台要求；不绕过登录、付费墙或访问限制。语音需获授权，不未经许可克隆真人声音。

Check copyright, licenses, and platform terms before reusing source media. Do not bypass login, paywalls, or access controls. Use authorized voices; do not clone a real person without permission.

## 脱敏说明 · Sanitization

本组合包含为公开使用重新整理的通用技能说明和参数校验脚本；未打包个人配置、私人后台域名、作者/分类偏好、账号凭据、后台截图、任务记录、本机绝对路径、原帖媒体或私有项目工程。

This bundle contains newly prepared, general-purpose skill guidance and a media validation script. It excludes personal settings, private admin domains, author/category preferences, credentials, admin screenshots, task records, absolute local paths, source-post media, and private project files.

仓库未附带第三方软件、其源码或第三方许可；不对本包另行授予开源许可证。 / No third-party software, source code, or third-party licenses are bundled; no separate open-source license is granted to this package.
