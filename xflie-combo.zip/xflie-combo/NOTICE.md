# Notice

This bundle's skill texts were newly authored for a general workflow and are not copies of locally installed companion-skill directories. The media verification utility is included from the separately published Xflie package. External tools are referenced only as optional dependencies; they are not included. No license is granted by this notice.
