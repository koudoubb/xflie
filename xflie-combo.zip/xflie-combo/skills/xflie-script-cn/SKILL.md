---
name: xflie-script-cn
description: Research a source post and write a fact-grounded Simplified Chinese title and spoken script for short-form visual explainers. Use for script preparation, translation, and narration copy; not for rendering or publishing alone.
---

# Chinese Short-form Script

## Purpose
Turn the source material's essential idea and examples into clear, natural Simplified Chinese narration for a short-form video. Preserve the source's scope and distinguish verified facts from interpretation.

## Workflow
1. Read the complete source post and inspect relevant linked examples when factual claims, prices, availability, or usage terms matter.
2. Identify one central takeaway, the minimum supporting examples, and any limitations that change the meaning. Exclude platform chrome, engagement metrics, and unrelated biography.
3. Translate for spoken Chinese rather than word-for-word. Keep product names and domain names when useful; explain technical terms briefly in plain language.
4. Draft a concise bilingual headline and a conversational voiceover with a clear hook, progression, and landing. Do not add unsupported promises, fake demonstrations, or generic filler.
5. Check names, counts, pricing, free/paid status, dates, and claims against the source. Flag unresolved claims instead of presenting guesses as facts.
6. When the user requests an approval gate, show the headline and the complete narration script and wait before producing media. Preserve the approved wording; if a material correction is required, explain it and request approval for that change.

## Output
Provide the headline, target length or estimated duration, full narration, pronunciation notes for names when helpful, and any concise fact/rights caveats needed for production. Do not include author biographies or social engagement data unless they are central to the requested content.

## Boundaries
Do not claim a resource is free if it has paid tiers. Do not reproduce long passages from source material. Do not imitate or clone a real person's voice without explicit authorization.
