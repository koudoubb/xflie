---
name: xflie-motion-card
description: Design and implement polished vertical motion cards from approved scripts and real examples using HTML/CSS and an available renderer. Use for storyboards, visual direction, animation, and editable card projects.
---

# Vertical Motion Card Design

## Inputs and handoff
Use an approved narration/title, verified source facts, actual available images or video, target platform, and export constraints. If script approval is required and missing, prepare visual options only; do not silently rewrite approved copy.

## Design workflow
1. Reduce the message to a visual thesis and map each narration beat to a scene, real example, and readable on-screen label.
2. Derive palette and visual motifs from the examples. Favor clear hierarchy and legibility over ornamental effects; never let decoration obscure evidence.
3. Build a portrait 9:16 composition (1080×1920 by default). Keep title, case-study media, captions, and controls within a centered 3:4 safe area, with additional inner padding. Treat any platform-specific crop separately.
4. Prefer real source imagery and video. If reconstructing a UI, label it as an illustration when it could be mistaken for a real product capture. Preserve original media and licenses/attribution requirements.
5. Use restrained, intentional transitions and animation. Make the card work without relying on tiny text, rapid flashing, or motion that harms comprehension.
6. Keep the project editable and portable: avoid unnecessary remote dependencies, document required fonts/media, and make scene boundaries and timings explicit. If a renderer has a project contract, read the installed version's instructions before authoring.
7. Export a matching still cover from a stable frame or a dedicated cover composition. The cover and video must share aspect ratio and resolution.

## Review
Inspect representative rendered frames across all scenes, including the first and last frame. Verify important content against the safe area, confirm examples are legible and accurately represented, and check that motion timing agrees with narration. A successful browser preview alone does not verify the exported video.
