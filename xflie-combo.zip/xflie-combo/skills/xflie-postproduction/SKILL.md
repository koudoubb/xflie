---
name: xflie-postproduction
description: Prepare natural Chinese narration, semantic subtitles, synchronized edits, and validated short-form video exports. Use for voice, caption timing, audio/video quality control, and delivery.
---

# Short-form Postproduction

## Voice and timing
- Use an appropriately licensed Chinese voice, with a natural conversational delivery and consistent pronunciation. Do not clone a real person without explicit authorization.
- Keep the recording faithful to the approved script. Align scene changes and example footage to narration beats; do not force speech to fit by cutting meaningful words.
- Balance narration and music for clarity, avoid clipping, and inspect the final audio rather than relying only on waveform metadata.

## Captions
- Generate word- or phrase-level timing from the actual final voice track, then regroup into semantic subtitle segments.
- Use high-contrast white text with a dark outline or equivalent accessible treatment. Keep subtitles to at most two lines, with deliberate line breaks.
- Avoid isolated one-character lines, awkward breaks inside names, and captions that appear late or end before the corresponding speech. Check long lines at the final rendered font size.

## Export and QC
- Export an MP4 compatible with the target service; H.264/AAC, yuv420p, and fast-start metadata are useful defaults when supported.
- Verify resolution, frame rate, duration, codecs, audio presence, file size, and cover dimensions using a media probe.
- Review the actual exported file: sample representative scenes and subtitle-heavy moments; confirm motion, narration, music balance, transitions, and ending. Check for black frames, missing scenes, clipping, and truncated final speech.
- Deliver the video, matching cover, subtitle file, editable project, and a short factual validation summary. Clearly distinguish completed checks from items not auditioned or visually reviewed.
